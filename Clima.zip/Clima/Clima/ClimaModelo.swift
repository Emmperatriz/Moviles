//
//  ClimaModelo.swift
//  Clima
//
//  Created by Mac18 on 25/11/20.
//  Copyright © 2020 itm. All rights reserved.
//

import Foundation

struct ClimaModelo {
    let condicionID : Int
    let nombreCiudad: String
    let descripcionClima: String
    let temperaturaCelcius: Double
    
   
    var obtenerCondicionClima: String {
        switch condicionID {
        case 200...232:
           
            return ""
        case 300...321:
            return ""
        default:
            return ""
         }
    }
}
