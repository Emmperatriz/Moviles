//
//  ViewController.swift
//  Clima
//
//  Created by Mac18 on 22/11/20.
//  Copyright © 2020 itm. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate, ClimaManagerDelegate {
    func actualizaClima(clima: ClimaModelo) {
    //clima.temperaturaCelcius
        print( clima.condicionID)
        
    }
    
    
    var climaManager = ClimaManager()
    
    @IBOutlet weak var buscarTextField: UITextField!
    @IBOutlet weak var temperaturaLabel: UILabel!
    @IBOutlet weak var ciudadaLabel: UILabel!
    @IBOutlet weak var climaImageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        climaManager.delegado = self
        // Do any additional setup after loading the view.
        buscarTextField.delegate = self
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        buscarTextField.text = ""
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      
        //ciudadaLabel.text = buscarTextField.text
        print(buscarTextField.text!)
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if buscarTextField.text != ""{
            return true
        }else{
            buscarTextField.placeholder = "Escribe una ciudad"
            print("Debes escribir algo")
            return false
        }
    }
    
    @IBAction func BuscarButton(_ sender: UIButton) {
        print(buscarTextField.text!)
        ciudadaLabel.text = buscarTextField.text
        climaManager.fetchClima(nombreCiudad: buscarTextField.text!)
    }
}

