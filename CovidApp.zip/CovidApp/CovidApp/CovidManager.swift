//
//  CovidManager.swift
//  CovidApp
//
//  Created by Mac18 on 14/12/20.
//

import Foundation
protocol CovidManagerDelegate{
    func actualizarCovid(covid: CovidModelo)
}

struct CovidManager{
    var delegado: CovidManagerDelegate?
    
    let covidURL = "https://corona.lmao.ninja/v3/covid-19/countries"
    
    func fetchCovid(nombreCiudad: String){
        let urlString = "\(covidURL)/\(nombreCiudad)"
        print(urlString)
      
        realizarSolicitud(urlString: urlString)
    }

    func  realizarSolicitud(urlString: String){
        
        if let url = URL(string: urlString){
            let session = URLSession(configuration: .default)
            
            //let tarea = session.dataTask(with: url, completionHandler: handle(data:respuestas:error:))
            let tarea = session.dataTask(with: url) {
                (data, respuesta, error) in
                if error != nil{
                    print(error!)
                    return
                }
                if let datosSEguros = data {
                    if let covid = parseJSON(covidData: datosSEguros){
                        delegado?.actualizarCovid(covid: covid)
                    }
                    
                    //  let dataString = String(data: datosSEguros, encoding: .utf8)
                 //   print(dataString!)
                    
                }            }
            tarea.resume()
        }
    }
   /* func handle(data: Data?, respuestas: URLResponse?,error: Error?){
        if error != nil{
            print(error!)
            return
        }
        if let datosSEguros = data {
            let dataString = String(data: datosSEguros, encoding: .utf8)
            print(dataString!)
            
        }
    }*/
    func parseJSON(covidData: Data) -> CovidModelo?{
        let decoder  = JSONDecoder()
        do{
       let dataDecodificada = try decoder.decode(CovidData.self, from: covidData)
            /*
            print(dataDecodificada.country)
            print(dataDecodificada.cases)
            print(dataDecodificada.deaths)
            print(dataDecodificada.recovered)
            print(dataDecodificada.countryInfo.flag)*/
            let Pais = dataDecodificada.country
            let Activos = dataDecodificada.cases
            let Muertes = dataDecodificada.deaths
            let Recuperados = dataDecodificada.recovered
            let Bandera = dataDecodificada.countryInfo.flag
            
            // crear el objeto personalizado
            let ObjetoCovid = CovidModelo(nombrePais: Pais, muertes: Muertes, activos: Activos, recuperados: Recuperados, bandera: Bandera)
            return ObjetoCovid
        }catch{
            print(error)
            return nil
        }
        }
    
}
