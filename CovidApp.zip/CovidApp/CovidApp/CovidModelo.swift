//
//  CovidModelo.swift
//  CovidApp
//
//  Created by Mac18 on 16/12/20.
//

import Foundation

struct CovidModelo{
    
    let nombrePais: String
    let muertes: Int
    let activos: Int
    let recuperados: Int
    let bandera: String
}
