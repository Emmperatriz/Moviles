//
//  ViewController.swift
//  CovidApp
//
//  Created by Mac18 on 11/12/20.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate, CovidManagerDelegate {
    func actualizarCovid(covid: CovidModelo) {
        print(covid.activos)
        print(covid.recuperados)
        print(covid.muertes)
        print(covid.nombrePais)
        print(covid.bandera)
        
        DispatchQueue.main.async {
            self.NombreCiudadTextField.text = covid.nombrePais
            self.RecuperadosTextField.text = String(covid.recuperados)
            self.ActivosTextField.text = String(covid.activos)
            self.DefuncionesTextField.text = String(covid.muertes)
        }
    }
    
    
    
    var covidManager = CovidManager()
    
    @IBOutlet weak var BuscarCiudadTextField: UITextField!
    @IBOutlet weak var BuscarButton: UIButton!
    @IBOutlet weak var NombreCiudadTextField: UILabel!
    @IBOutlet weak var RecuperadosTextField: UILabel!
    @IBOutlet weak var ActivosTextField: UILabel!
    @IBOutlet weak var DefuncionesTextField: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        covidManager.delegado = self
        BuscarCiudadTextField.delegate = self
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        BuscarCiudadTextField.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        print(BuscarCiudadTextField.text!)
        covidManager.fetchCovid(nombreCiudad: BuscarCiudadTextField.text!)
        return true
    }
  
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if BuscarCiudadTextField.text != "" {
            return true
        }else {
            BuscarCiudadTextField.placeholder = "Escribe la ciudad"
            return false
        }
    }
    
    @IBAction func buscarButton(_ sender: UIButton) {
        print(BuscarCiudadTextField.text!)
        covidManager.fetchCovid(nombreCiudad: BuscarCiudadTextField.text!)
        
        
    }
    
    
}

