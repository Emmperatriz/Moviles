//
//  ClimaManager.swift
//  weatherApp
//
//  Created by Mac18 on 25/11/20.
//  Copyright © 2020 itm. All rights reserved.
//

import Foundation


protocol ClimaManagerDelegate {
    func actualizaClima(clima: ClimaModelo)
    func huboError(cualError: Error)
    
 
}

struct ClimaManager {
    
    var delegado: ClimaManagerDelegate?
    
    let climaURL = "https://api.openweathermap.org/data/2.5/weather?appid=d6b4dd6466869a2e4f8e11759a67cd75&units=metric&lang=es"
    
    func fetchClima(nombreCiudad: String){
        let urlString = "\(climaURL)&q=\(nombreCiudad)"
        print(urlString)
        realizarSolicitud(urlString: urlString)
    }
    func fetchClima(lat: Double, lon: Double){
        let urlString = "\(climaURL)&lat=\(lat)&lon=\(lon)"
        realizarSolicitud(urlString: urlString)
    }
    
    func realizarSolicitud(urlString : String){
        //1.-Crear la URL
        if let url = URL(string: urlString){
            //2.-crear el objeto URLSession
            let session = URLSession(configuration: .default)
            //3.-Asignar una tarea
            //let tarea = session.dataTask(with: url, completionHandler: handle(data:respuesta:error:))
            let tarea = session.dataTask(with: url){(data,respuesta, error) in
                if error != nil {
                    //print(error)
                    self.delegado?.huboError(cualError:  error!)
                    return
                }
                if let datosSeguros = data {
                    //crear el obj personalizado
                    if let clima = self.parseJSON(climaData: datosSeguros){
                        self.delegado?.actualizaClima(clima: clima)
                    }
                    
                    
                    
                }
            }
            //4.-Iniciar la tarea
            tarea.resume()
        }
        
    }
    func parseJSON(climaData: Data)-> ClimaModelo? {
        
        let decoder = JSONDecoder()
        do {
            let dataDecodificada = try decoder.decode(ClimaData.self, from: climaData)
           
            let id = dataDecodificada.weather[0].id
            let nombre = dataDecodificada.name
            let temperatura = dataDecodificada.main.temp
            let descripcion = dataDecodificada.weather[0].description
            
            let tem_min = dataDecodificada.main.temp_min
            let tem_max = dataDecodificada.main.temp_max
            let speed = dataDecodificada.wind.speed
            // Crear obl personalizado
            let ObjClima = ClimaModelo(condicionID: id, nombreCiudad: nombre, descripcionClima: descripcion, temperaturaCelcius: temperatura, temp_max: tem_max, temp_min: tem_min, speed: speed)
            return ObjClima
        }catch{
           // print(error)
            delegado?.huboError(cualError: error)
            return nil
        }
    }
    
}
