//
//  ClimaModelo.swift
//  weatherApp
//
//  Created by Mac18 on 25/11/20.
//  Copyright © 2020 itm. All rights reserved.
//

import Foundation

struct ClimaModelo {
    let condicionID : Int
    let nombreCiudad: String
    let descripcionClima: String
    let temperaturaCelcius: Double
    
    
    let temp_max: Double
    let temp_min: Double
    let speed: Double
   
   
    
    var obtenerCondicionClima: String {
        switch condicionID {
        case 200...232:
            
            return "tormentaFondo.jpg"
        case 300...321:
            return "drizzleFondo.jpg"
        case 500...531:
            return "lluviaFondo"
        case 600...622:
            return "nieveFondo.jpg"
        case 800:
            return "soleadooo.jpg"
        default:
            return "default.png"
        }
    }
    
}
