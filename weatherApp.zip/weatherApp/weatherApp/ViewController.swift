//
//  ViewController.swift
//  weatherApp
//
//  Created by Mac18 on 25/11/20.
//  Copyright © 2020 itm. All rights reserved.
//

import UIKit
import CoreLocation


class ViewController: UIViewController{
    var locationManager = CLLocationManager()
    
    var climaManager = ClimaManager()
    
    

    @IBOutlet weak var buscarTextField: UITextField!
    
    @IBOutlet weak var imagenFondoClima: UIImageView!
    
    @IBOutlet weak var descripcionClimaLabel: UILabel!
    
    @IBOutlet weak var temperaturaLabel: UILabel!
    @IBOutlet weak var ciudadaLabel: UILabel!
    @IBOutlet weak var climaImageView: UIImageView!
    
    @IBOutlet weak var temMaxLabel: UILabel!
    @IBOutlet weak var temMinLabel: UILabel!
    
    @IBOutlet weak var velovidadLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.delegate = self
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        
        climaManager.delegado = self
       
        buscarTextField.delegate = self
      
        
        
    }
    

    
    @IBAction func BuscarButton(_ sender: UIButton) {
        print(buscarTextField.text!)
        ciudadaLabel.text = buscarTextField.text
        climaManager.fetchClima(nombreCiudad: buscarTextField.text!)
        
    }
    
    @IBAction func obtenerUbicacionButton(_ sender: UIButton) {
        locationManager.requestLocation()
       
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
}


extension ViewController : CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("ubicacion Obtenida")
        if let ubicacion = locations.last{
            let lat = ubicacion.coordinate.latitude
            let lon = ubicacion.coordinate.longitude
            print("lat: \(lat), \(lon)")
            climaManager.fetchClima(lat: lat, lon: lon)
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
    
}
extension ViewController : ClimaManagerDelegate{
    
    func huboError(cualError: Error) {
        DispatchQueue.main.async {
            // self.ciudadaLabel.text = cualError.localizedDescription
            let aviso = UIAlertController(title: "¡Advertencia!", message: "No se obtuvo el nombre de la ciudad.", preferredStyle: .alert)
            let actionOk = UIAlertAction(title: "Enterado", style: .default, handler: nil)
            aviso.addAction(actionOk)
            self.present(aviso, animated: true, completion: nil)
            
        }
        print(cualError.localizedDescription)
    }
    
    func actualizaClima(clima: ClimaModelo) {
         print(clima.temperaturaCelcius)
         print( clima.condicionID)
         print(clima.descripcionClima)
         print(clima.nombreCiudad)
         print(clima.speed)

        DispatchQueue.main.async {
            self.temperaturaLabel.text = String(clima.temperaturaCelcius)
            self.ciudadaLabel.text = clima.nombreCiudad
            self.descripcionClimaLabel.text = clima.descripcionClima
            self.imagenFondoClima.image = UIImage(named: clima.obtenerCondicionClima)
            self.temMaxLabel.text = String(clima.temp_max)
            self.temMinLabel.text = String(clima.temp_min)
            self.velovidadLabel.text = String(clima.speed)
            
        }
    }
   
}
extension ViewController :  UITextFieldDelegate {
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        buscarTextField.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //ciudadaLabel.text = buscarTextField.text
        print(buscarTextField.text!)
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if buscarTextField.text != ""{
            return true
        }else{
            buscarTextField.placeholder = "Escribe una ciudad"
            print("Debes escribir algo")
            return false
        }
    }
    
   
    
}


